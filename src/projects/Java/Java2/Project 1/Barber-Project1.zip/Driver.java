/**
 * Driver class runs Project 1 simulation
 *
 * @author Jake Barber
 * @version 10/3/16
 */
public class Driver
{
    public static void main(String[] args)
    {
        Controller c = new Controller();
        c.end();
    }
}
