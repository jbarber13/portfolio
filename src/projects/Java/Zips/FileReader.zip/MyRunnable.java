public abstract class MyRunnable implements Runnable{
  

}