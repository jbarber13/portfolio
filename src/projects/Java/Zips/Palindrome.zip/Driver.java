/**   Driver.java   Runs Project 2 Palindrome tester
 *
 * @author Jake Barber
 * @version 10/17/16
 */
public class Driver{
   public static void main(String[] args){
      Controller c = new Controller();
   }
}