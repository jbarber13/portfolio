/**   Contoller.java   Launches the view for Project 2 Palindrome tester
 *
 * @author Jake Barber
 * @version 10/17/16
 */
public class Controller  {
   public Controller(){   
      View v = new View(new javax.swing.JFrame(), true);
   }
}